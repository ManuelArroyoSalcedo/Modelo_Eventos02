
package compo1;

import java.util.EventListener;

/**
 *
 * @author Manuel Arroyo Salcedo
 */
public interface IF_Provincias extends EventListener{
    public void Ejecuta(EO_Provincias eveObj);
}
